import pygame
import sys
import random
import math
import asyncio

pygame.init()

WIDTH, HEIGHT = 960, 640
FPS = 60
TILE = 40

BG_TOP    = (5, 10, 30)
BG_BOT    = (10, 30, 70)
BLACK     = (0, 0, 0)
WHITE     = (255, 255, 255)
ICE       = (180, 230, 255)
CYAN      = (0, 200, 255)
BLUE      = (30, 90, 200)
DEEP      = (15, 45, 120)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ice Platformer")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 32, bold=True)
big_font = pygame.font.SysFont("Arial", 64, bold=True)

LEVELS = [
    [
        "..............................",
        "..............................",
        "..............................",
        "..............................",
        "..............................",
        "..........C.......C...........",
        ".........====....====.........",
        "..............................",
        "..P...................F.......",
        "##############################",
    ],
    [
        "..............................",
        "..............................",
        "..........C..C................",
        "........====..====............",
        "..............................",
        "....C.......E.......C.........",
        "...===.....====....====.......",
        "..............................",
        "..P..................F........",
        "##############################",
    ],
    [
        "..............................",
        "..............................",
        "..............................",
        "..........C...C...............",
        ".........#######..............",
        "....E...........E.............",
        "..#####.......#####...........",
        ".....C..C..C..C..C..C.........",
        "..P.......................F...",
        "##############################",
    ],
    [
        "..............................",
        "..............................",
        "..........C.C.C...............",
        "........=========.............",
        "..............................",
        "....E..........E..............",
        "..####........####............",
        "..............................",
        "..P...........C.......F.......",
        "#####.......#####.....########",
    ],
    [
        "..............................",
        "......................C.......",
        "....................=====.....",
        "..............C...............",
        "............=====.............",
        "........C.....................",
        "......=====...................",
        "....C.........................",
        "..P.......................F...",
        "##############################",
    ],
    [
        "..............................",
        "..............................",
        "....C.........C.........C.....",
        "...====.....=====.....====....",
        "..E.....E.......E.......E.....",
        "..###..###..###..###..###.....",
        "....C.........C...............",
        "..P.......................F...",
        "##############################",
    ],
    [
        "..............................",
        "..............................",
        "....C.....C.....C.....C.......",
        "...==....==....==....==.......",
        "..............................",
        "..E......E......E......E......",
        "..===...====...====...====....",
        "..............................",
        "..P.......C.........C.....F...",
        "##############################",
    ],
    [
        "..............................",
        ".....................C........",
        "..................=====.......",
        "..............E...............",
        "...........=====..............",
        ".....C........................",
        "..=====.......................",
        "..............................",
        "..P.......C........C......F...",
        "##############################",
    ],[
        "..............................",
        "........C.........C...........",
        "......=====.....=====.........",
        "..............................",
        "..E......E......E......E......",
        "..####...####...####...####...",
        "..............................",
        "..C...C...C...C...C...C.......",
        "...==..==..==..==..==..==.....",
        "..P.......................F...",
        "##############################",
    ],
    [
        "..............................",
        "....C...C...........C...C.....",
        "...=====.............=====....",
        "..............................",
        "..E.......E.....E.......E.....",
        "..####..#####..#####..####....",
        "..............................",
        "..C..C..C..C..C..C..C..C..C...",
        "...==...==...==...==...==..=..",
        "..P.......................F...",
        "##############################",
    ],
]

class Cloud:
    def __init__(self, x, y, scale, speed, alpha):
        self.x = x
        self.y = y
        self.scale = scale
        self.speed = speed
        self.alpha = alpha
        self.base_w = 220
        self.base_h = 90
        self.blobs = [
            (0.00, 0.55, 0.42),
            (0.28, 0.30, 0.50),
            (0.55, 0.45, 0.55),
            (0.72, 0.60, 0.40),
            (0.40, 0.65, 0.45),
        ]
        self.surf = self._make_surface()

    def _make_surface(self):
        w = int(self.base_w * self.scale)
        h = int(self.base_h * self.scale)
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        for bx, by, br in self.blobs:
            cx = int(bx * w)
            cy = int(by * h)
            r = int(br * h)
            pygame.draw.circle(surf, (140, 200, 255, self.alpha), (cx, cy), r)
        return surf

    def update(self, dt):
        self.x += self.speed * dt
        if self.x > WIDTH + 200:
            self.x = -self.surf.get_width() - 200

    def draw(self, surf, cam_x):
        px = self.x - cam_x * 0.15
        surf.blit(self.surf, (px, self.y))

def make_clouds():
    clouds = []
    rng = random.Random(42)
    for _ in range(10):
        x = rng.uniform(-200, WIDTH + 200)
        y = rng.uniform(30, 260)
        scale = rng.uniform(0.6, 1.6)
        speed = rng.uniform(6, 18)
        alpha = rng.randint(30, 80)
        clouds.append(Cloud(x, y, scale, speed, alpha))
    return clouds

class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 32, 40)
        self.vel_x = 0
        self.vel_y = 0
        self.on_ground = False
        self.speed = 5
        self.jump = -14
        self.gravity = 0.7
        self.start = (x, y)
        self.coins = 0

    def update(self, keys, platforms):
        self.vel_x = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.vel_x = -self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.vel_x = self.speed

        self.rect.x += self.vel_x
        for p in platforms:
            if self.rect.colliderect(p):
                if self.vel_x > 0:
                    self.rect.right = p.left
                elif self.vel_x < 0:
                    self.rect.left = p.right

        if (keys[pygame.K_SPACE] or keys[pygame.K_UP] or keys[pygame.K_w]) and self.on_ground:
            self.vel_y = self.jump
            self.on_ground = False

        self.vel_y += self.gravity
        if self.vel_y > 20:
            self.vel_y = 20
        self.rect.y += self.vel_y

        self.on_ground = False
        for p in platforms:
            if self.rect.colliderect(p):
                if self.vel_y > 0:
                    self.rect.bottom = p.top
                    self.vel_y = 0
                    self.on_ground = True
                elif self.vel_y < 0:
                    self.rect.top = p.bottom
                    self.vel_y = 0

    def draw(self, surf, cam):
        r = self.rect.move(-cam[0], -cam[1])
        pygame.draw.rect(surf, WHITE, r, border_radius=6)
        pygame.draw.rect(surf, CYAN, r, width=3, border_radius=6)
        pygame.draw.circle(surf, BLACK, (r.x + 10, r.y + 14), 4)
        pygame.draw.circle(surf, BLACK, (r.x + 22, r.y + 14), 4)
        pygame.draw.circle(surf, CYAN, (r.x + 11, r.y + 13), 2)
        pygame.draw.circle(surf, CYAN, (r.x + 23, r.y + 13), 2)

class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x + 8, y + 8, 24, 24)
        self.start = (self.rect.x, self.rect.y)
        self.dir = 1
        self.speed = 2
        self.alive = True
        self.left_bound = self.rect.x - TILE * 3
        self.right_bound = self.rect.x + TILE * 3
        self.base_y = self.rect.y
        self.bob_time = 0

    def update(self, platforms=None):
        if not self.alive:
            return
        self.rect.x += self.dir * self.speed
        if self.rect.x <= self.left_bound:
            self.rect.x = self.left_bound
            self.dir = 1
        elif self.rect.x >= self.right_bound:
            self.rect.x = self.right_bound
            self.dir = -1
        self.bob_time += 0.08
        self.rect.y = self.base_y + int(math.sin(self.bob_time) * 6)

    def draw(self, surf, cam):
        if not self.alive:
            return
        r = self.rect.move(-cam[0], -cam[1])
        pygame.draw.rect(surf, DEEP, r, border_radius=8)
        pygame.draw.rect(surf, CYAN, r, width=2, border_radius=8)
        pygame.draw.circle(surf, ICE, (r.x + 7, r.y + 9), 3)
        pygame.draw.circle(surf, ICE, (r.x + 17, r.y + 9), 3)
        pygame.draw.line(surf, CYAN, (r.x - 4, r.y + 6), (r.x - 8, r.y + 2), 2)
        pygame.draw.line(surf, CYAN, (r.x - 4, r.y + 16), (r.x - 8, r.y + 20), 2)
        pygame.draw.line(surf, CYAN, (r.right + 4, r.y + 6), (r.right + 8, r.y + 2), 2)
        pygame.draw.line(surf, CYAN, (r.right + 4, r.y + 16), (r.right + 8, r.y + 20), 2)

class Coin:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x + 10, y + 10, 20, 20)
        self.collected = False

    def draw(self, surf, cam):
        if self.collected:
            return
        r = self.rect.move(-cam[0], -cam[1])
        pygame.draw.circle(surf, CYAN, r.center, 10)
        pygame.draw.circle(surf, WHITE, r.center, 10, 2)
        pygame.draw.circle(surf, WHITE, (r.centerx - 3, r.centery - 3), 3)

def parse_level(data):
    platforms, coins, enemies, finish = [], [], [], None
    player_pos = (100, 100)
    for row_i, row in enumerate(data):
        for col_i, ch in enumerate(row):
            x, y = col_i * TILE, row_i * TILE
            if ch == "#":
                platforms.append(pygame.Rect(x, y, TILE, TILE))
            elif ch == "=":
                platforms.append(pygame.Rect(x, y, TILE, TILE // 2))
            elif ch == "C":
                coins.append(Coin(x, y))
            elif ch == "E":
                enemies.append(Enemy(x, y))
            elif ch == "P":
                player_pos = (x + 4, y)
            elif ch == "F":
                finish = pygame.Rect(x, y, TILE, TILE)
    return platforms, coins, enemies, finish, player_pos

def draw_bg(surf):
    for y in range(HEIGHT):
        t = y / HEIGHT
        r = int(BG_TOP[0] * (1 - t) + BG_BOT[0] * t)
        g = int(BG_TOP[1] * (1 - t) + BG_BOT[1] * t)
        b = int(BG_TOP[2] * (1 - t) + BG_BOT[2] * t)
        pygame.draw.line(surf, (r, g, b), (0, y), (WIDTH, y))

def draw_platform(surf, rect, is_ground):
    if is_ground:
        pygame.draw.rect(surf, DEEP, rect, border_radius=4)
        pygame.draw.rect(surf, CYAN, rect, width=2, border_radius=4)
        pygame.draw.rect(surf, ICE, (rect.x, rect.y, rect.width, 4))
    else:
        pygame.draw.rect(surf, BLUE, rect, border_radius=4)
        pygame.draw.rect(surf, ICE, rect, width=2, border_radius=4)
        pygame.draw.rect(surf, WHITE, (rect.x, rect.y, rect.width, 2))

def draw_text(surf, text, fnt, color, x, y, center=False, shadow=True):
    if shadow:
        sh = fnt.render(text, True, BLACK)
        rect = sh.get_rect()
        if center:
            rect.center = (x + 2, y + 2)
        else:
            rect.topleft = (x + 2, y + 2)
        surf.blit(sh, rect)
    img = fnt.render(text, True, color)
    rect = img.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    surf.blit(img, rect)

async def main():
    clouds = make_clouds()
    state = "menu"
    level_index = 0
    total_coins = 0

    def load_level(i):
        data = LEVELS[i]
        plats, cs, es, fin, ppos = parse_level(data)
        player = Player(*ppos)
        return plats, cs, es, fin, player

    plats, coins, enemies, finish, player = load_level(level_index)
    world_w = max(p.right for p in plats) + 100
    world_h = max(p.bottom for p in plats) + 100

    running = True

    while running:
        dt_ms = clock.tick(FPS)
        dt = dt_ms / 1000.0

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            if e.type == pygame.KEYDOWN:
                if state == "menu" and e.key == pygame.K_RETURN:
                    level_index = 0
                    total_coins = 0
                    plats, coins, enemies, finish, player = load_level(0)
                    world_w = max(p.right for p in plats) + 100
                    world_h = max(p.bottom for p in plats) + 100
                    state = "play"
                elif state in ("win", "gameover", "victory") and e.key == pygame.K_RETURN:
                    if state == "win":
                        total_coins += player.coins
                        level_index += 1
                        if level_index >= len(LEVELS):
                            state = "victory"
                        else:
                            plats, coins, enemies, finish, player = load_level(level_index)
                            world_w = max(p.right for p in plats) + 100
                            world_h = max(p.bottom for p in plats) + 100
                            state = "play"
                    elif state == "gameover":
                        plats, coins, enemies, finish, player = load_level(level_index)
                        state = "play"
                    else:
                        state = "menu"
                elif state == "play" and e.key == pygame.K_r:
                    plats, coins, enemies, finish, player = load_level(level_index)
                elif state == "play" and e.key == pygame.K_ESCAPE:
                    state = "menu"

        if state == "play":
            keys = pygame.key.get_pressed()
            player.update(keys, plats)

            for en in enemies:
                en.update(plats)
                if en.alive and player.rect.colliderect(en.rect):
                    if player.vel_y > 0 and player.rect.bottom - en.rect.top < 20:
                        en.alive = False
                        player.vel_y = -10
                    else:
                        state = "gameover"

            for c in coins:
                if not c.collected and player.rect.colliderect(c.rect):
                    c.collected = True
                    player.coins += 1

            if finish and player.rect.colliderect(finish):
                state = "win"

            if player.rect.top > world_h:
                state = "gameover"

        cam_x = player.rect.centerx - WIDTH // 2
        cam_y = player.rect.centery - HEIGHT // 2
        cam_x = max(0, min(cam_x, world_w - WIDTH))
        cam_y = max(0, min(cam_y, world_h - HEIGHT))
        cam = (cam_x, cam_y)

        for cl in clouds:
            cl.update(dt)

        draw_bg(screen)
        for cl in clouds:
            cl.draw(screen, cam[0])

        if state == "menu":
            draw_text(screen, "ICE PLATFORMER", big_font, ICE, WIDTH // 2, 150, center=True)
            pygame.draw.line(screen, CYAN, (WIDTH // 2 - 250, 200), (WIDTH // 2 + 250, 200), 2)
            draw_text(screen, "10 levels", font, CYAN, WIDTH // 2, 240, center=True)
            draw_text(screen, "Arrows / A-D - move", font, WHITE, WIDTH // 2, 310, center=True)
            draw_text(screen, "Space / W / Up - jump", font, WHITE, WIDTH // 2, 355, center=True)
            draw_text(screen, "R - restart", font, WHITE, WIDTH // 2, 400, center=True)
            draw_text(screen, "ESC - menu", font, WHITE, WIDTH // 2, 445, center=True)
            draw_text(screen, "Press ENTER to start", font, CYAN, WIDTH // 2, 540, center=True)

        elif state == "play":
            for p in plats:
                r = p.move(-cam[0], -cam[1])
                draw_platform(screen, r, p.height == TILE)
            for c in coins:
                c.draw(screen, cam)
            for en in enemies:
                en.draw(screen, cam)
            if finish:
                fr = finish.move(-cam[0], -cam[1])
                pygame.draw.rect(screen, CYAN, fr, border_radius=8)
                pygame.draw.rect(screen, WHITE, fr.inflate(-12, -12), border_radius=6)
                pygame.draw.rect(screen, ICE, fr.inflate(-22, -22), border_radius=4)
            player.draw(screen, cam)
            draw_text(screen, "Coins: " + str(player.coins), font, ICE, 20, 20)
            draw_text(screen, "Level " + str(level_index + 1) + "/10", font, ICE, WIDTH - 260, 20)

        elif state == "win":
            draw_text(screen, "LEVEL COMPLETE", big_font, ICE, WIDTH // 2, HEIGHT // 2 - 80, center=True)
            draw_text(screen, "Crystals: " + str(player.coins), font, CYAN, WIDTH // 2, HEIGHT // 2 - 10, center=True)
            draw_text(screen, "ENTER - next", font, CYAN, WIDTH // 2, HEIGHT // 2 + 80, center=True)

        elif state == "gameover":
            draw_text(screen, "GAME OVER", big_font, CYAN, WIDTH // 2, HEIGHT // 2 - 60, center=True)
            draw_text(screen, "ENTER - retry", font, WHITE, WIDTH // 2, HEIGHT // 2 + 40, center=True)

        elif state == "victory":
            draw_text(screen, "VICTORY!", big_font, ICE, WIDTH // 2, HEIGHT // 2 - 100, center=True)
            draw_text(screen, "All 10 levels complete!", font, CYAN, WIDTH // 2, HEIGHT // 2 - 20, center=True)
            draw_text(screen, "Total: " + str(total_coins), font, WHITE, WIDTH // 2, HEIGHT // 2 + 40, center=True)
            draw_text(screen, "ENTER - menu", font, CYAN, WIDTH // 2, HEIGHT // 2 + 110, center=True)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())